<div id='clickmeter-warning' class='updated fade'>
	<h3>Your settings have been saved</h3>
</div>