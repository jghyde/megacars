<div id='clickmeter-warning' class='updated fade'>
	<table>
		<tr>
			<td><a href="<?php echo $link; ?>"><div style="padding: 8px 8px;" class="clickmeter-button"><strong>Activate ClickMeter!</strong></div></a></td>
			<td><span style="padding-left:20px">Clickmeter's plugin is almost ready. Click on the button to activate the plugin!</span></td>
		</tr>
	</table>
</div>