<?php 
?>

<html>
<style type="text/css">

body {
	color: #444;
	font-family: "Open Sans",sans-serif;
	font-size: 15px;
	line-height: 1.4em;
}

.spinner {
	background: url('/wp-content/plugins/clickmeter-link-shortener-and-analytics/img/spinner.gif') no-repeat;
	background-size: 30px 30px;
	display: block;
	width: 30px;
	height: 30px;
	padding:5px;
}
</style>

<script type="text/javascript">
	document.write('<center><div style="padding: 10px 0px 10px 0px"><span><div class="spinner"></div>Please wait some seconds</span></div></center>');
</script>
<body>

</body>
</html>
